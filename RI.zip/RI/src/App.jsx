import "./App.css";
import CheckoutPage from "./components/CheckOutPage/CheckoutPage";

function App() {
  return (
    <>
      <div className="navbar">NavBar</div>
      <CheckoutPage />
    </>
  );
}

export default App;
